# -*- coding: utf-8 -*-
from random import uniform, sample
from numpy import *
import os
import operator
import rw as rw
RELATIONDIM=20
DIM=20
DEBUG=False
BASE_DIR = os.getcwd()
DATA_DIR=BASE_DIR+"/"
pattern=['time_5','time_4','time_3','time_2','time_1']
action=['type1','type2','type3','type4','type5','type6','type7','type8','type9','type10','type11']
class Test:
    def __init__(self,fcodeList,fcodeVectorList,entityList,entityVectorList,relationList ,relationVectorList, relationMatrixList,tripleListTrain, label = "tail"):
        self.fcodeList = fcodeList
        self.fcodeVectorList=fcodeVectorList
        self.entityList = entityList
        self.entityVectorList = entityVectorList
        self.relationList     = relationList
        self.relationVectorList = relationVectorList
        self.relationMatrixList = relationMatrixList
        self.tripleListTrain = tripleListTrain
        self.tailRank = []
        self.relationRank=[]
        self.relationRank_t=[]
        self.relationRank_b=[]
        self.label = label        
        self.eventRank=[]
        self.PRESION=[]
        self.RECALL=[]
    def writeEventRank(self, dir):
        print("writing")
        file = open(dir, 'w')
        for r in self.eventRank:
            file.write(str(r[0]) + "\t")
            file.write(str(r[1]) + "\t")
            file.write("rank"+"\t"+str(r[2]) + "\t")
            file.write("size"+"\t"+str(r[3]) + "\n")
        file.close()
    def getPresion(self):
        sum=0.0
        top1_count=0
        for i in self.eventRank:
            sum+=1
            if i[2]==1:
                top1_count+=1
        Presion=top1_count/sum

        return Presion


    def predictEvent(self):
        count = 0#实验次数            
        for sequence in self.tripleListTrain:
            #length=len(sequence)
            #index=int(uniform(2,length-1))
            index=0
            triplet = sequence[index]
            if (len(triplet)>0):
                eRankList={}
                corruptedTripletSize2=0
                u  = self.entityVectorList[triplet[0]]#u
                l  = self.fcodeVectorList[triplet[1]]#l
                a  = self.relationVectorList[triplet[2]]
                Ma = self.relationMatrixList[triplet[2]]
                r  = self.relationVectorList[triplet[3]]
                Mr = self.relationMatrixList[triplet[3]]
                d0=distance_projection_L2(u,l,a,Ma)+distance_projection_L2(u,l,r,Mr)
                eRankList[(triplet[0],triplet[1],triplet[2],triplet[3])]=d0
                #for l0 in self.fcodeList:
                for a0 in action:
                    for r0 in pattern:
                        corruptedTriplet = [triplet[0],triplet[1], a0,r0]
                        if corruptedTriplet not in sequence:
                            a0_vec=self.relationVectorList[a0]#
                            Ma0= self.relationMatrixList[a0]
                            r0_vec = self.relationVectorList[r0]#r
                            Mr0=self.relationMatrixList[r0]
                            dis=distance_projection_L2(u,l,a0_vec,Ma0)+distance_projection_L2(u,l,r0_vec,Mr0)
                            corruptedTripletSize2 += 1
                            eRankList[(triplet[0],triplet[1],a0,r0)] = dis            
                            #localRank.append((triplet,d0,corruptedTriplet,dis))
                    #print(rankList)
                nameRank = sorted(eRankList.items(),key=operator.itemgetter(1))
                x=1
                for i in nameRank:
                    if i[0] == (triplet[0],triplet[1],triplet[2],triplet[3]):
                        break
                    x += 1
                self.eventRank.append((triplet, nameRank[0][0], x ,corruptedTripletSize2))
            count += 1
            if count % 1000 == 0:
                print(str(count)+"triplets")            
 
def distance_projection_L2(h,t,r,matrix):#checked
        
        h=array(h)
        t=array(t)
        r=array(r)
        #print(shape(h),shape(t),shape(r),shape(matrix))
        h1=[]
        t1=[]
        for i in range(RELATIONDIM-1):
            tmp1=0.0
            tmp2=0.0
            for j in range(DIM):
                tmp1+=matrix[j,i]*h[j]
                tmp2+=matrix[j,i]*t[j]
            h1.append(tmp1)
            t1.append(tmp2)
        sum=0.0
        for i in range(RELATIONDIM-1):
                sum+=(h1[i]+r[i]-t1[i])**2
        return sqrt(sum)                
            
def distance(h, t, r):#求欧氏距离
    h = array(h)
    t = array(t)
    r = array(r)
    s = h + r - t
    return linalg.norm(s)




if __name__ == '__main__':
    #dirTrain = DATA_DIR+"/trainDataset_samp.txt"
    NumTrain, tripleListTrain = rw.openSequenceQuadruple(DATA_DIR+"koubei_test.txt")
    ralationnum,relationList=rw.openDetailsAndId(DATA_DIR+"relation2id.txt")
    entitynum,entityList=rw.openDetailsAndId(DATA_DIR+"entity2id.txt")
    fcodenum,fcodeList=rw.openDetailsAndId(DATA_DIR+"fcode2id.txt")
    entityVectorList=rw.loadData(DATA_DIR+"entityVector.txt")
    fcodeVectorList=rw.loadData(DATA_DIR+"fcodeVector.txt")
    relationVectorList=rw.loadData(DATA_DIR+"relationVector.txt")
    relationMatrixList=rw.loadMatrix(DATA_DIR+"relationMatrix.txt")
    
    test=Test(fcodeList,fcodeVectorList,entityList,entityVectorList,relationList ,relationVectorList, relationMatrixList,tripleListTrain)
    
    

    
    test.predictEvent()
        
    test.writeEventRank(DATA_DIR+"testEventPredction" + ".txt")
    print("accuracy:",test.getPresion())

    