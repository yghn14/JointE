# -*- coding: utf-8 -*-
"""
读写数据

"""
from random import uniform, sample
from numpy import *
import operator
import os
BASE_DIR = os.getcwd()
#DATA_DIR = BASE_DIR+"/petrol_lenUpper50/"
import json
import codecs  
import re  

'''
    44383	62	62	62	62	62	62	93	62	62	62	
    ...
'''
def openSequencesAndId(dir,sp="\t"):#返回id数量，实体数组
    idNum = 0
    list = []
    with open(dir) as file:
        lines = file.readlines()
        for line in lines:
            DetailsAndId = line.strip().split(sp)
            list.append(DetailsAndId[1:])
            idNum += 1
    return idNum, list
'''
   1 1
   2 2
   ...
'''
def openAndTranSequence(dir,sp="\t"):
    Num,list = openSequenceQuadruple(dir)
    dirData=BASE_DIR+"/petrol/trainDataset_koubei.txt"
    with open(dirData,"w") as fileData:
        for sequence in list:
            for i in range(0,len(sequence)-1):#最后一次交易无法计算时间间隔
                tx_i=sequence[i]
                tx_next=sequence[i+1]
                tx_i[3]=int(tx_next[3])-int(tx_i[3])
                tx_i.pop()
                fileData.write("(")
                for item in tx_i:
                    fileData.write(str(item)+",")
                fileData.write(")")
                fileData.write("\t")
            fileData.write("\n")
#将数据集里的miu离散化成7个值,并与12个行为类型合并
def openAndTranDATASET(dir,sp="\t"):
    list = []
    with open(dir) as file:
        lines = file.readlines()
        for line in lines:
            temp=[]
            seq = line.strip().split(sp)
            for quadruple in seq:
                detail=quadruple[1:-1].strip().split(",")
                temp.append(detail)
            list.append(temp)
    dirData=DATA_DIR+"/trainDatasetMiu.txt"
    with open(dirData,"w") as fileData:
        for sequence in list:
            for i in range(0,len(sequence)):#最后一次交易无法计算时间间隔
                delta="intelval_7"
                tx_i=sequence[i]
                days=int(tx_i[3])
                if days<=3.5:
                    delta="intelval_1"
                if days>3.5 and days<=7:
                    delta="intelval_2"
                if days>7 and days<=10:
                    delta="intelval_3"
                if days>10 and days<=14:
                    delta="intelval_4"
                if days>14 and days<=21:
                    delta="intelval_5"
                if days>21 and days<=30:
                    delta="intelval_6"
                r=delta+"_"+tx_i[2]
                tx_i[2]=r
                fileData.write("(")
                for item in tx_i:
                    fileData.write(str(item)+",")
                fileData.write(")")
                fileData.write("\t")
            fileData.write("\n")

#将数据集里的delta离散化成6个值  (...,u-2s],(u-2s,u-s](u-s,u](u,u+s](u+s,u+2s](u+2s,...)
def openAndTranDATASET():
    #NumTrain, tripleListTrain = openSequenceQuadruple(dir)
    dir1=BASE_DIR+"/koubei/Miu_sigma.txt"
    dir2=BASE_DIR+"/petrol_lenUpper50/Miu_sigma_petrol_lenUpper50.txt"
    dic_u={}
    dic_s={}
    with open(dir2) as file:
        lines = file.readlines()
        for line in lines:
            line=line.strip().split("\t")
            user=line[0]
            u=float(line[1])
            s=float(line[2])
            dic_u[user]=u
            dic_s[user]=s
    dir3=BASE_DIR+"/koubei/trainDataset_koubei.txt"
    dir4=BASE_DIR+"/petrol_lenUpper50/Dataset_petrol_lenUpper50.txt"
    dir5=BASE_DIR+"/koubei/trainDataset_koubei_transfer.txt"
    dir6=BASE_DIR+"/petrol_lenUpper50/Dataset_petrol_lenUpper50_transfer.txt"
    num,data=openSequenceQuadruple(dir4)
    with open(dir6,"w") as fileData:
        for sequence in data:
            user=sequence[0][0]
            for i in range(0,len(sequence)):
                tx=sequence[i]
                tx.pop()
                days=float(tx[3])
                delta="time_1"#(...,u-2s]
                if days>(dic_u[user]-2*dic_s[user]) and days<=(dic_u[user]-dic_s[user]):
                    delta="time_2"#(u-2s,u-s]
                if days>(dic_u[user]-dic_s[user]) and days<=(dic_u[user]+dic_s[user]):
                    delta="time_3"#(u-2s,u-s]
                if days>(dic_u[user]+dic_s[user]) and days<=(dic_u[user]+2*dic_s[user]):
                    delta="time_4"#(u-2s,u-s]
                if days>(dic_u[user]+2*dic_s[user]):
                    delta="time_5"#(u-2s,u-s]
                tx[3]=delta
                fileData.write("(")
                for item in tx:
                    fileData.write(str(item)+",")
                fileData.write(")")
                fileData.write("\t")
            fileData.write("\n")



def openDetailsAndId(dir,sp="\t"):#返回id数量，实体数组
    idNum = 0
    list = []
    with open(dir) as file:
        lines = file.readlines()
        for line in lines:
            DetailsAndId = line.strip().split(sp)
            list.append(DetailsAndId[0])
            idNum += 1
    return idNum, list
'''
    1	9
    2	9
    ...
'''
def loadregion(dir):
    fr = open(dir)
    sArr = [line.strip().split("\t") for line in fr.readlines()]
    nameArr = [line[0] for line in sArr]
    datArr = [line[1] for line in sArr]
    return  nameArr,datArr
'''
    1	{"x":114.353085,"y":30.590046,"wkid":4326}
    2	{"x":114.302187,"y":30.529367,"wkid":4326}
'''
def opencoordinate(dir,sp="\t"):
    idNum = 0
    fcode_coordinate={}
    with open(dir) as file:
        lines = file.readlines()
        for line in lines:
            Detail = line.strip().split(sp)
            fcode=Detail[0]
            xy=json.loads(Detail[1])
            fcode_coordinate[fcode]=xy
            idNum += 1
    return idNum, fcode_coordinate
def openSequenceQuadruple(dir,sp="\t"):
    idNum = 0
    list = []
    with open(dir) as file:
        lines = file.readlines()
        for line in lines:
            temp=[]
            seq = line.strip().split(sp)
            for quadruple in seq:
                detail=quadruple[1:-1].strip().split(",")
                temp.append(detail)
            list.append(temp)
            
            idNum += 1
    return idNum, list
'''
'''
def loadData(dir):#读取训练好的地点向量
    entityVectorList={}
    fr = open(dir)
    sArr = [line.strip().split("\t") for line in fr.readlines()]
    datArr = [[float(s) for s in line[1][1:-1].split(", ")] for line in sArr]
    nameArr = [line[0] for line in sArr]
    for name, vec in zip(nameArr, datArr):
            entityVectorList[name] = array(vec)
    return entityVectorList
def loadneg_dic(dir):
    neg_dic={}
    fr=open(dir)
    sArr = [line.strip().split("\t") for line in fr.readlines()]
    nameArr = [line[0] for line in sArr]
    datArr = [[s.strip("'") for s in line[1][1:-1].split(", ")] for line in sArr]
    for name, vec in zip(nameArr, datArr):
            neg_dic[name] = vec
    return neg_dic
def loadMatrix(str):
    Matrixlist={}
    fr = open(str)
    nameArr=[]
    dataArr=[]
    for line in fr.readlines():
        l=line.strip().split("\t")
        nameArr.append(l[0])        
        mat=[[float(s) for s in l2[1:-1].strip().split(",")] for l2 in l[1][0:-1].strip().split(";")]
        dataArr.append(array(mat))
    for name, vec in zip(nameArr, dataArr):
            Matrixlist[name] = vec
    return Matrixlist            
def writeEntilyVector(entityList, dir):
        print("写入实体")
        entityVectorFile = open(dir, 'w')
        for entity in entityList.keys():
            entityVectorFile.write(entity+"\t")
            entityVectorFile.write(str(entityList[entity]))
            entityVectorFile.write("\n")
        entityVectorFile.close()
#第一列作为key，后面的列转为list作为value
def loadRelationClu(dir):
    relationDic={}
    fr=open(dir)
    sArr = [line.strip().split("\t") for line in fr.readlines()]
    nameArr = [line[0] for line in sArr]
    datArr = [line[1:] for line in sArr]
    for name, vec in zip(nameArr, datArr):
            relationDic[name] = vec
    return relationDic
#平均类内距离
def Avg(clu,relationVectorList):#clu 属于一簇的关系  relationVectorDic关系向量字典
    num=len(clu)
    sum=0.0
    for i in clu:
        for j in clu:
            sum+=distanceL2(relationVectorList[i],relationVectorList[j])
    result=sum*2
    if num>1:
        result=sum*2/(num*(num-1))
    return result
#计算DB指数
def getDBI(CentroidDic,relationClu,relationVectorList,clusterIndex):
    sum=0.0
    count=0.0
    for label_i in CentroidDic.keys():
        count+=1
        temp_i=[]
        distRank={}
        for key in relationClu.keys():#key 关系
            if relationClu[key][clusterIndex]==label_i:
                temp_i.append(key)
        avg_i=Avg(temp_i,relationVectorList)
        #print(avg_i)
        for label_j in CentroidDic.keys():
            if label_i!=label_j:
                temp_j=[]
        
                for key in relationClu.keys():
                    if relationClu[key][clusterIndex]==label_j:
                        temp_j.append(key)
                #print(temp_j)
                avg_j=Avg(temp_j,relationVectorList)
                distRank[label_j]=(avg_i+avg_j)/distanceL2(CentroidDic[label_i],CentroidDic[label_j])
                #print(avg_i)
        nameRank = sorted(distRank.items(),key=operator.itemgetter(1),reverse=True)
        #print(nameRank)
        sum+=nameRank[0][1]
    #print(sum)
    return sum/count
#计算DB指数
def getDBI_community(CentroidDic,relationClu,relationVectorList,clusterIndex):
    sum=0.0
    count=0.0
    dic_label_r={}#key:簇标签 value：簇里的关系 r
    for label_i in CentroidDic.keys():#簇标签
        temp_i=[]#簇i 包含的关系 r
        for key in relationClu.keys():#关系 r
            if relationClu[key][clusterIndex]==label_i:
                temp_i.append(key)
        dic_label_r[label_i]=temp_i
    for label_i in CentroidDic.keys():#簇标签
        count+=1
        distRank={}
        avg_i=Avg(dic_label_r[label_i],relationVectorList)
        #print(avg_i)
        for label_j in CentroidDic.keys():
            if label_i!=label_j:
                avg_j=Avg(dic_label_r[label_j],relationVectorList)
                distRank[label_j]=(avg_i+avg_j)/centDis(dic_label_r,relationVectorList,label_i,label_j)
                #print(avg_i)
        nameRank = sorted(distRank.items(),key=operator.itemgetter(1),reverse=True)
        #print(nameRank)
        sum+=nameRank[0][1]
    #print(sum)
    return sum                                                                                              
def centDis(dic_label_r,relationVectorList,Ci,Cj):
    size1=len(dic_label_r[Ci])
    size2=len(dic_label_r[Cj])
    total=0.0
    for r1 in dic_label_r[Ci]:
        for r2 in dic_label_r[Cj]:
            total+=distanceL2(relationVectorList[r1],relationVectorList[r2])
    return total/(size1*size2)
            
    
def getCentroidDic(clusters_index,relationVectorList,relationDic):
    clusters = clusters_index
    #relationDic=rw.loadRelationClu(BASE_DIR+"/data/tranE/cluster/relationVectorCluster_40_10.txt")
    centroid_Clu_dic={}
    centroid_Clu_dic_tmp={}
    labels=[]#簇标签
    for key in relationDic.keys():
        if relationDic[key][clusters] not in labels:
            labels.append(relationDic[key][clusters])
    #print(labels)
    for l in labels:
        centroid_Clu_dic_tmp[l]=[]
    for clu in centroid_Clu_dic_tmp.keys():
        for r in relationDic.keys():
            if clu==relationDic[r][clusters]:
                centroid_Clu_dic_tmp[clu].append(relationVectorList[r])
    for key in centroid_Clu_dic_tmp.keys():
        centroid_Clu_dic[key]=getMean(centroid_Clu_dic_tmp[key])
    return centroid_Clu_dic

#arr_list包含一组向量，计算一组向量中心点
def getMean(arr_list):
    num=len(arr_list)
    result=[]
    for index in range(0,len(arr_list[0])):
        result.append(0.0)
    for arr in arr_list:
        for i in range(0,len(arr)):
            result[i]+=arr[i]
    for i in range(0,len(result)):
        result[i]=result[i]/num
    return result    
def distanceL2(h, t):#h+r与t的距离平方
    h=array(h)
    t=array(t)    
    s = h - t
    sum = (s*s).sum()
    return sum     
#将训练数据集里的关系由84种变为20种
def loadAndTransDataset(dir):
    relationClu=loadRelationClu(BASE_DIR+"/data/tranE/cluster/relationVectorCluster_40_10.txt")
    dir1 = BASE_DIR+"/data/tranE/trainDataset.txt"
    NumTrain, tripleListTrain = openSequenceQuadruple(dir1)
    dir2=BASE_DIR+"/data/tranE/trainDataset20relation.txt"
    with open(dir2,"w") as fileData:
        for sequence in tripleListTrain:
            for i in sequence:# i是7元组
                r=i[2]
                newRalation="relationType_"+str(relationClu[r][10])
                i[2]=newRalation
                fileData.write("(")
                for item in i:
                    fileData.write(str(item)+",")
                fileData.write(")")
                fileData.write("\t")
            fileData.write("\n")
def getAve(list):
    num=len(list)
    result=0.0
    s =0.0
    for i in list:
        s +=i
    if num>0:
        result = s*1.0/num
    return result
def getStandard(list):
    num=len(list)
    s =0.0
    ave =getAve(list)
    for i in list:
        s += (i-ave)*(i-ave)
    return sqrt(s/(num-1))
#过滤掉list中（u-2s,u+2s）之外的数
def getFiltMiuSigma(list):
    #print(list)
    flag=True#flag=1表示所有元素都在（u-2s,u+2s）内
    Miu=getAve(list)
    sigma=getStandard(list)
    #print("----")
    #print(Miu)
    #print(sigma)
    l=Miu-2*sigma
    r=Miu+2*sigma
    #print(l)
    #print(r)
    #print("----")
    for i in list:
        if i <l or i>r:
            #print(i)
            list.remove(i)
            flag=False
    if flag:
        return list
    else:
        list=getFiltMiuSigma(list)
        return list

def getKOUBEIcategory(dir):
    idNum = 0
    list = []
    with open(dir) as file:
        lines = file.readlines()
        for line in lines:
            DetailsAndId = line.strip().split(",")
            list.append(DetailsAndId[7:])
            idNum += 1
    categoryLevel1={}
    categoryLevel2={}
    for line in list:
        c1=line[0]
        c2=line[1]
        if len(line)==3:
            c3=line[2]
        if c1 not in categoryLevel1.keys:
            categoryLevel1[c1]={}
        if c2 not in categoryLevel2.keys:
            categoryLevel2[c2]={}
    for line in list:
        c1=line[0]
        c2=line[1]
        if len(line)==3:
            c3=line[2]
            categoryLevel2[c2]=c3
            categoryLevel1[c1]=c2
    return idNum, list
  
    
if __name__ == "__main__":

    
    dirTrain1 = BASE_DIR+"/koubei.txt"        
    dirtest = BASE_DIR+"/koubei_test.txt"     
    NumTrain, tripleListTrain = openSequenceQuadruple(dirTrain1)
    
    
    with open(dirtest,"w") as fileData:
        for sequence in tripleListTrain:
            length=len(sequence)
            
            index=int(uniform(2,length-1))
            e=sequence[index]
            fileData.write("(")

            fileData.write(str(e[0])+","+str(e[1])+","+str(e[2])+","+str(e[3]))
            fileData.write(")")
            fileData.write("\n")
    
            
    