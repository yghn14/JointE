﻿# -*- coding: utf-8 -*-

from random import uniform, sample
from numpy import *
from copy import deepcopy
import os
import rw as rw
BASE_DIR = os.getcwd()
DATA_DIR = BASE_DIR+"/"
RELATIONDIM=20
DIM=20
LEARNINGRATE=0.001
CONTEXTSIZE=1
NEGATIVESIZE=5
X="x"
Y="y"
class newtranR:
    def __init__(self,fcodeList,entityList, relationList, tripleList,neg_dic, coordinateDict ,Mat={},relationMatrixList={}, margin = 1.0, learingRate = LEARNINGRATE, dim = DIM, relationDim=RELATIONDIM , L1 = False):
        self.fcodeList=fcodeList
        self.entityList = entityList#
        self.relationList = relationList#
        self.tripleList = tripleList#
        self.neg_dic= neg_dic
        self.coordinateDict=coordinateDict#
        self.Mat=Mat#
        self.relationMatrixList = relationMatrixList#
        self.margin = margin
        self.learingRate = learingRate
        self.dim = dim
        self.relationDim = relationDim
        self.loss = 0.0
        self.L1 = L1#
        
    def initialize(self):
        entityVectorList = {}
        fcodeVectorList={}
        relationVectorList = {}
        relationMatrixList= {}
        for entity in self.entityList:#为每个实体初始化为dim维的向量
            n = 0
            entityVector = []
            while n < self.dim:
                ram = init(self.dim)#初始化的范围
                entityVector.append(ram)
                n += 1
            entityVector = norm_vec(entityVector)#归一化
            entityVectorList[entity] = entityVector#key是entity，values是其向量
        print("entityVectorList初始化完成，数量是%d"%len(entityVectorList))
        
        for fcode in self.fcodeList:#为每个实体初始化为dim维的向量
            n = 0
            fcodeVector = []
            while n < self.dim:
                ram = init(self.dim)#初始化的范围
                fcodeVector.append(ram)
                n += 1
            fcodeVector = norm_vec(fcodeVector)#归一化
            fcodeVectorList[fcode] = fcodeVector#key是entity，values是其向量
        print("fcodeVectorList初始化完成，数量是%d"%len(fcodeVectorList))
        
        for relation in self. relationList:
            n = 0
            ii= 0
            relationVector = []
            #relationMatrix=eye(self.dim,self.relationDim,dtype=float)
            relationMatrix=zeros([self.dim,self.relationDim])
            while ii<self.dim:#
                jj= 0
                while jj<self.relationDim:
                    if ii==jj:
                        relationMatrix[ii][jj]=init(self.relationDim)
                    jj += 1
                ii += 1
            while n < self.relationDim:
                ram = init(self.relationDim)#初始化的范围
                relationVector.append(ram)
                n += 1
            relationVector = norm_vec(relationVector)#归一化
            relationVectorList[relation] = relationVector
            relationMatrixList[relation]=relationMatrix
        #print("relationMatrix不是对角阵")
        print("relationVectorList初始化完成，数量是%d"%len(relationVectorList))
        print("relationMatrixList初始化完成，数量是%d,形状是%d*%d"%(len(relationMatrixList),shape(relationMatrix)[0],shape(relationMatrix)[1]))

        self.Mat=self.getDistanceMatrix()
        self.entityList = entityVectorList
        self.relationList = relationVectorList
        self.relationMatrixList=relationMatrixList
        self.fcodeList=fcodeVectorList
        self.writeRelationVector(DATA_DIR+"ini_relationVector.txt")
        self.writeRelationMatrix(DATA_DIR+"ini_relationMatrix.txt")
        self.writeEntityVector(DATA_DIR+"ini_entityVector.txt")
        self.writefcodeVector(DATA_DIR+"ini_fcodeVector.txt")
        print("tripleList初始化完成，数量是%d"%len(tripleList))
        print("ini successful")
    def newtranR(self, cI = 100000):
        print("训练开始")
        for cycleIndex in range(0,cI):
            #Sbatch = self.tripleList
            Sbatch = sample(self.tripleList,100)##用户序列的集合
            Tbatch = []#元组对（原三元组，打碎的三元组）的列表 ：{((h,r,t),(h',r',t))}
            for sequence in Sbatch:#用户序列
                length = len(sequence)
                for index in range(CONTEXTSIZE,length-CONTEXTSIZE):
                    triplet = sequence[index]#(user,fcode,r)
                    u  = triplet[0]
                    li = triplet[1]
                    r0 = triplet[2]
                    r1 = triplet[3]
                
                    '''context '''
                    l_context = self.getcontext(sequence,index)
                    l_neg = self.getneg(u,NEGATIVESIZE)
                    for lc in l_context:
                        self.update_context(li,lc,1)
                    '''negative'''
                    for ln in l_neg:
                        self.update_context(li,ln,-1)
                        CorruptedTriplet=[u,ln,r0,r1]
                        tripletWithCorruptedTriplet=(triplet,CorruptedTriplet)
                        if(tripletWithCorruptedTriplet not in Tbatch):
                            Tbatch.append(tripletWithCorruptedTriplet)
            self.update(Tbatch)
            if cycleIndex % 1== 0:
               print("第%d次循环"%cycleIndex)
               self.loss = self.getloss()
               print("loss  "+str(self.loss))
               self.writeRelationVector(DATA_DIR+"relationVector.txt")
               self.writeRelationMatrix(DATA_DIR+"relationMatrix.txt")
               self.writeEntityVector(DATA_DIR+"entityVector.txt")
               self.writefcodeVector(DATA_DIR+"fcodeVector.txt")
               self.loss = 0

    
    def update(self, Tbatch):
        #copy \u6d45\u62f7\u8d1d \u53ea\u62f7\u8d1d\u7236\u5bf9\u8c61\uff0c\u4e0d\u4f1a\u62f7\u8d1d\u5bf9\u8c61\u7684\u5185\u90e8\u7684\u5b50\u5bf9\u8c61\u3002deepcopy \u6df1\u62f7\u8d1d \u62f7\u8d1d\u5bf9\u8c61\u53ca\u5176\u5b50\u5bf9\u8c61
        copyEntityList = deepcopy(self.entityList)#entityList\u8bad\u7ec3\u8fc7\u7a0b\u4e2d\u4f1a\u88ab\u66f4\u65b0
        copyfcodeList = deepcopy(self.fcodeList)
        copyRelationList = deepcopy(self.relationList)
        copyrelationMatrixList = deepcopy(self.relationMatrixList)
        for triplet_Negtriplet in Tbatch:#tripletWithCorruptedTriplet是原三元组和打碎的三元组的元组tuple:((h,t,r)(h',t',r))
            #print(triplet_Negtriplet)
            h0=triplet_Negtriplet[0][0]#(h,t,r)中的h
            t0=triplet_Negtriplet[0][1]#(h,t,r)中的t
            r0=triplet_Negtriplet[0][2]#(h,t,r)中的r0
            r1=triplet_Negtriplet[0][3]#(h,t,r)中的r1
            h1=triplet_Negtriplet[1][0]#(h,t,r)中的h'
            t1=triplet_Negtriplet[1][1]#(h,t,r)中的t'
            
            '''
            变量后缀为0表示变量值未更新（self.List）,变量后缀为1表示变量值被更新（copyList）
        
            '''
            h_Vec1  = copyEntityList[h0]#(h,t,r)中的h
            t_Vec1  = copyfcodeList[t0]##(h,t,r)中的t
            r0_Vec1  = copyRelationList[r0]#(h,t,r)中的r0
            r0_Matrix1 = copyrelationMatrixList[r0]
            r1_Vec1  = copyRelationList[r1]#(h,t,r)中的r1
            r1_Matrix1 = copyrelationMatrixList[r1]
            h1_Vec1 =copyEntityList[h1]#(h,t,r)中的h'
            t1_Vec1 = copyfcodeList[t1]#(h,t,r)中的t'
            
            h_Vec0  = self.entityList[h0]#(h,t,r)中的h
            t_Vec0  = self.fcodeList[t0]##(h,t,r)中的t
            r0_Vec0  = self.relationList[r0]#(h,t,r)中的r0
            r0_Matrix0 = self.relationMatrixList[r0]
            r1_Vec0  = self.relationList[r1]#(h,t,r)中的r0
            r1_Matrix0 = self.relationMatrixList[r1]
            h1_Vec0 = self.entityList[h1]#(h,t,r)中的h'
            t1_Vec0 = self.fcodeList[t1]#(h,t,r)中的t'
            
            
            distTriplet_based_r0 = distance_projection_L2(h_Vec0 , t_Vec0 , r0_Vec0 , r0_Matrix0)         #\u6b63\u4f8b\u5143\u7ec4\u8ddd\u79bb
            distCorruptedTriplet_based_r0 = distance_projection_L2(h1_Vec0, t1_Vec0, r0_Vec0 , r0_Matrix0)#\u8d1f\u4f8b\u5143\u7ec4\u8ddd\u79bb
            #print("distTriplet "+str(distTriplet) +"distCorruptedTriplet "+str(distCorruptedTriplet))
            eg = self.margin + distTriplet_based_r0 - distCorruptedTriplet_based_r0
            if eg > 0: #[function]+ \u662f\u4e00\u4e2a\u53d6\u6b63\u503c\u7684\u51fd\u6570
            
                for j in range(self.relationDim):
                    h_pos =0.0
                    t_pos =0.0
                    h_Neg =0.0
                    t_Neg =0.0
                    distPos =0.0
                    distNeg =0.0
                    for i in range(self.dim):
                        h_pos  += h_Vec0[i]  * r0_Matrix0[i,j]
                        t_pos  += t_Vec0[i]  * r0_Matrix0[i,j]
                        h_Neg  += h1_Vec0[i] * r0_Matrix0[i,j]
                        t_Neg  += t1_Vec0[i] * r0_Matrix0[i,j]
                    distPos  = 2 * (h_pos  + r0_Vec0[j] - t_pos)
                    distNeg  = 2 * (h_Neg  + r0_Vec0[j] - t_Neg)
                    for i in range(self.dim):
                        r0_Matrix0[i,j] -= self.learingRate* distPos  *(h_Vec0[i] - t_Vec0[i])
                        r0_Matrix0[i,j] += self.learingRate* distNeg  *(h1_Vec0[i] - t1_Vec0[i])
                        h_Vec0[i] -= self.learingRate * distPos * r0_Matrix0[i,j]#h
                        t_Vec0[i] += self.learingRate * distPos * r0_Matrix0[i,j]#t
                        h1_Vec0 += self.learingRate * distNeg *r0_Matrix0[i,j]#h'
                        t1_Vec0 -= self.learingRate * distNeg *r0_Matrix0[i,j]#t'
                    r0_Vec0[j] -= self.learingRate*distPos 
                    r0_Vec0[j] += self.learingRate*distNeg
                h_Vec1  =h_Vec0
                t_Vec1  =t_Vec0
                r0_Vec1  =r0_Vec0
                r0_Matrix1=r0_Matrix0
                h1_Vec1 =h1_Vec0
                t1_Vec1 =t1_Vec0
                copyEntityList[h0]  = norm_vec(h_Vec1)#h
                copyfcodeList[t0]   = norm_vec(t_Vec1)#t
                copyRelationList[r0]= norm_vec(r0_Vec1)#r
                copyEntityList[h1]  = norm_vec(h1_Vec1)#h'
                copyfcodeList[t1]   = norm_vec(t1_Vec1)#t'
                copyEntityList[h0],copyrelationMatrixList[r0]=norm(h_Vec1,r0_Matrix1)#h,A
                copyfcodeList[t0],copyrelationMatrixList[r0] =norm(t_Vec1,r0_Matrix1)#t,A
                copyEntityList[h1],copyrelationMatrixList[r0]=norm(h1_Vec1,r0_Matrix1)#h',A
                copyfcodeList[t1], copyrelationMatrixList[r0]= norm(t1_Vec1,r0_Matrix1)#t'
                
                
            distTriplet_based_r1 = distance_projection_L2(h_Vec0 , t_Vec0 , r1_Vec0 , r1_Matrix0)         #\u6b63\u4f8b\u5143\u7ec4\u8ddd\u79bb
            distCorruptedTriplet_based_r1 = distance_projection_L2(h1_Vec0, t1_Vec0, r1_Vec0 , r1_Matrix0)#\u8d1f\u4f8b\u5143\u7ec4\u8ddd\u79bb
            #print("distTriplet "+str(distTriplet) +"distCorruptedTriplet "+str(distCorruptedTriplet))
            eg = self.margin + distTriplet_based_r1 - distCorruptedTriplet_based_r1
            if eg > 0: #[function]+ \u662f\u4e00\u4e2a\u53d6\u6b63\u503c\u7684\u51fd\u6570
            
                for j in range(self.relationDim):
                    h_pos =0.0
                    t_pos =0.0
                    h_Neg =0.0
                    t_Neg =0.0
                    distPos =0.0
                    distNeg =0.0
                    for i in range(self.dim):
                        h_pos  += h_Vec0[i]  * r1_Matrix0[i,j]
                        t_pos  += t_Vec0[i]  * r1_Matrix0[i,j]
                        h_Neg  += h1_Vec0[i] * r1_Matrix0[i,j]
                        t_Neg  += t1_Vec0[i] * r1_Matrix0[i,j]
                    distPos  = 2 * (h_pos  + r1_Vec0[j] - t_pos)
                    distNeg  = 2 * (h_Neg  + r1_Vec0[j] - t_Neg)
                    for i in range(self.dim):
                        r1_Matrix0[i,j] -= self.learingRate* distPos  *(h_Vec0[i] - t_Vec0[i])
                        r1_Matrix0[i,j] += self.learingRate* distNeg  *(h1_Vec0[i] - t1_Vec0[i])
                        h_Vec0[i] -= self.learingRate * distPos * r1_Matrix0[i,j]#h
                        t_Vec0[i] += self.learingRate * distPos * r1_Matrix0[i,j]#t
                        h1_Vec0 += self.learingRate * distNeg *r1_Matrix0[i,j]#h'
                        t1_Vec0 -= self.learingRate * distNeg *r1_Matrix0[i,j]#t'
                    r1_Vec0[j] -= self.learingRate*distPos 
                    r1_Vec0[j] += self.learingRate*distNeg
                h_Vec1  =h_Vec0
                t_Vec1  =t_Vec0
                r1_Vec1  =r1_Vec0
                r1_Matrix1=r1_Matrix0
                h1_Vec1 =h1_Vec0
                t1_Vec1 =t1_Vec0
                copyEntityList[h0]  = norm_vec(h_Vec1)#h
                copyfcodeList[t0]   = norm_vec(t_Vec1)#t
                copyRelationList[r1]= norm_vec(r1_Vec1)#r
                copyEntityList[h1]  = norm_vec(h1_Vec1)#h'
                copyfcodeList[t1]   = norm_vec(t1_Vec1)#t'
                copyEntityList[h0],copyrelationMatrixList[r1]=norm(h_Vec1,r1_Matrix1)#h,A
                copyfcodeList[t0],copyrelationMatrixList[r1] =norm(t_Vec1,r1_Matrix1)#t,A
                copyEntityList[h1],copyrelationMatrixList[r1]=norm(h1_Vec1,r1_Matrix1)#h',A
                copyfcodeList[t1], copyrelationMatrixList[r1]=norm(t1_Vec1,r1_Matrix1)#t'
                
        self.entityList = copyEntityList
        self.relationList = copyRelationList
        self.relationMatrixList = copyrelationMatrixList
        self.fcodeList=copyfcodeList
    def update_context(self, li,l,alpha):
        d=self.getdistance(li,l)
        if li!=l:#pair是不同的两个fcode
            copyfcodeList = deepcopy(self.fcodeList)#entityList训练过程中会被更新
            targetVectorbeforeupdate=self.fcodeList[li]#targetlocation
            targetVector=copyfcodeList[li]
            lVectorbeforeupdate=self.fcodeList[l]
            lVector=copyfcodeList[l]
     
            if alpha>0:#li和l是context关系
                for i in range(0,self.dim):
                    targetVectorbeforeupdate[i] +=self.learingRate*alpha*(1-sigmoid(dot(targetVectorbeforeupdate,lVectorbeforeupdate)))*lVectorbeforeupdate[i]*(1/d)
                    lVectorbeforeupdate[i]      +=self.learingRate*alpha*(1-sigmoid(dot(targetVectorbeforeupdate,lVectorbeforeupdate)))*targetVectorbeforeupdate[i]*(1/d)
            
            else :#li和l是neg关系
                for i in range(0,self.dim):
                    targetVectorbeforeupdate[i] +=self.learingRate*alpha*sigmoid(dot(targetVectorbeforeupdate,lVectorbeforeupdate))*lVectorbeforeupdate[i]
                    lVectorbeforeupdate[i]      +=self.learingRate*alpha*sigmoid(dot(targetVectorbeforeupdate,lVectorbeforeupdate))*targetVectorbeforeupdate[i]
            
            targetVector=targetVectorbeforeupdate
            lVector=lVectorbeforeupdate
            copyfcodeList[li]=norm_vec(targetVector)
            copyfcodeList[l]=norm_vec(lVector) 
            self.fcodeList=copyfcodeList
        else:
            pass
    def getloss(self):
        for sequence in self.tripleList:
            for triplet in sequence:
                h = self.entityList[triplet[0]]
                t = self.fcodeList[triplet[1]]
                r0 = self.relationList[triplet[2]]
                r1 = self.relationList[triplet[3]]
                matrix0 = self.relationMatrixList[triplet[2]]
                matrix1 = self.relationMatrixList[triplet[3]]
                #print(self.loss)
                self.loss += distance_projection_Loss(h,t,r0,matrix0)
                self.loss += distance_projection_Loss(h,t,r1,matrix1)
        return self.loss
        
    def getSample(self, size):
        return sample(self.tripleList, size)
    def getneg(self,user,size):
        return sample(self.neg_dic[user],size)
    def getcontext(self,sequence,index):
        tmp=[]
        for x in range(0,CONTEXTSIZE):
            tmp.append(sequence[index-x][1])
            tmp.append(sequence[index+x][1])
        return tmp


    def writeEntityVector(self, dir):
        print("写入实体")
        entityVectorFile = open(dir, 'w')
        for entity in self.entityList.keys():
            entityVectorFile.write(entity+"\t")
            entityVectorFile.write(str(self.entityList[entity].tolist()))
            entityVectorFile.write("\n")
        entityVectorFile.close()
    def writefcodeVector(self, dir):
        print("写入fcode")
        entityVectorFile = open(dir, 'w')
        for entity in self.fcodeList.keys():
            entityVectorFile.write(entity+"\t")
            entityVectorFile.write(str(self.fcodeList[entity].tolist()))
            entityVectorFile.write("\n")
        entityVectorFile.close()

    def writeRelationVector(self, dir):
        print("写入关系vector")
        relationVectorFile = open(dir, 'w')
        for relation in self.relationList.keys():
            relationVectorFile.write(relation + "\t")
            relationVectorFile.write(str(self.relationList[relation].tolist()))
            relationVectorFile.write("\n")
        relationVectorFile.close()
        
    def writeRelationMatrix(self, dir):
        print("写入关系matrix")
        relationMatrixFile = open(dir, 'w')
        for relation in self.relationList.keys():
            relationMatrixFile.write(relation + "\t")
            for item in self.relationMatrixList[relation]:
                relationMatrixFile.write(str(item.tolist()))
                relationMatrixFile.write(";")
            relationMatrixFile.write("\n")
        relationMatrixFile.close()
    
    def getDistanceMatrix(self):#\u83b7\u53d6\u7ad9\u70b9\u4e4b\u95f4\u7684\u8ddd\u79bb\u77e9\u9635
        Mat={}
        for fcode1 in self.coordinateDict.keys():
            dis={}
            for fcode2 in self.coordinateDict.keys():
                x1=self.coordinateDict[fcode1][X]
                y1=self.coordinateDict[fcode1][Y]
                x2=self.coordinateDict[fcode2][X]
                y2=self.coordinateDict[fcode2][Y]
                distance=sqrt((x1-x2)**2+(y1-y2)**2)#\u6b27\u5f0f\u8ddd\u79bb
                dis[fcode2]=distance*1.0
            Mat[fcode1]=dis
        return Mat
    def getdistance(self,fcode1,fcode2):#\u82e5\u4e24\u4e2a\u7ad9\u70b9\u7ecf\u7eac\u5ea6\u90fd\u6709\uff0c\u8fd4\u56de\u5176\u8ddd\u79bb\uff1b\u4e0d\u7136\u8fd4\u56de1
        t=1.0
        if fcode1 in self.Mat.keys():
            if fcode2 in self.Mat[fcode1].keys():
                t= sigmoid(self.Mat[fcode1][fcode2])
        return t
def init(dim):
    return uniform(-6/(dim**0.5), 6/(dim**0.5))#\u4ea7\u751f\u968f\u673a\u6570\u4f4d\u4e8e\uff08\u66f4\u53f7k\u5206\u4e4b6\uff09
def distanceL1(h, t ,r):#h+r\u4e0et\u7684\u8ddd\u79bb\u7edd\u5bf9\u503c
    s = h + r - t
    sum = fabs(s).sum()
    return sum
def distanceL2(h, t, r):#h+r\u4e0et\u7684\u8ddd\u79bb\u5e73\u65b9
    s = h + r - t
    sum = (s*s).sum()
    return sum
def norm_vec(list):
    '''\u5f52\u4e00\u5316vector'''
    var = linalg.norm(list)#\u8ba1\u7b97\u5411\u91cf\u7684\u6a21
    i = 0
    while i < len(list):
        list[i] = list[i]/var
        i += 1
    return array(list)
def distance_projection_L1(h,t,r,matrix):#h,t:dim\u7ef4\uff0cr\uff1arelationDim\u7ef4\uff0cmatrix\uff1adim*relationDim\u7ef4
        h1=[]
        t1=[]
        for i in range(0,RELATIONDIM):
            tmp1=0.0
            tmp2=0.0
            for j in range(0,DIM):
                tmp1+=matrix[j,i]*h[j]
                tmp2+=matrix[j,i]*h[j]
            h1.append(tmp1)
            t1.append(tmp2)
        sum=0.0
        for i in range(0,RELATIONDIM):
            sum+=abs(h1[i]+r[i]-t1[i])
        return sum
        
def norm(list,matrix):#list\uff1adim\u7ef4,matrix\uff1adim*relationDim\u7ef4
    while True:       
        x=0.0
        for j in range(RELATIONDIM):
            temp=0.0
            for i in range(DIM):
                temp+=matrix[i,j]*list[i]
            x+=(temp*temp)
        if x>1:
            for j in range(RELATIONDIM):
                temp=0.0
                for i in range(DIM):
                    temp+=matrix[i,j]*list[i]
                temp*=2.0
                for i in range(DIM):
                    list[i]     -= LEARNINGRATE*temp*matrix[i,j]
                    matrix[i,j]-=LEARNINGRATE*temp*list[i]       
        else:
            break
    return list,matrix

def distance_projection_L2(h,t,r,matrix):#h,t:dim\u7ef4\uff0cr\uff1arelationDim\u7ef4\uff0cmatrix\uff1adim*relationDim\u7ef4
        h1=[]
        t1=[]
        for i in range(RELATIONDIM):
            tmp1=0.0
            tmp2=0.0
            for j in range(DIM):
                tmp1+=matrix[j,i]*h[j]
                tmp2+=matrix[j,i]*t[j]
            h1.append(tmp1)
            t1.append(tmp2)
        sum=0.0
        for i in range(RELATIONDIM):
                sum+=(h1[i]+r[i]-t1[i])**2
        return sqrt(sum)           
def distance_projection_Loss(h,t,r,matrix):#h,t:dim\u7ef4\uff0cr\uff1arelationDim\u7ef4\uff0cmatrix\uff1adim*relationDim\u7ef4
        h1=[]
        t1=[]
        for i in range(RELATIONDIM-1):
            tmp1=0.0
            tmp2=0.0
            for j in range(DIM):
                tmp1+=matrix[j,i]*h[j]
                tmp2+=matrix[j,i]*t[j]
            h1.append(tmp1)
            t1.append(tmp2)
        sum=0.0
        for i in range(RELATIONDIM-1):
                sum+=(h1[i]+r[i]-t1[i])**2
        return sqrt(sum)  

def sigmoid(x):
    return 1.0/(1+exp(-x))    
if __name__ == '__main__':
    fcodeNum, fcodeList = rw.openDetailsAndId(DATA_DIR+"fcode2id.txt")
    entityIdNum, entityList = rw.openDetailsAndId(DATA_DIR+"entity2id.txt")
    relationIdNum, relationList = rw.openDetailsAndId(DATA_DIR+"relation2id.txt")
    tripleNum, tripleList = rw.openSequenceQuadruple( DATA_DIR+"koubei.txt")
    neg_dic=rw.loadneg_dic(DATA_DIR+"neg_dic.txt")
    #idnum,coordinateDict=rw.opencoordinate(DATA_DIR+"coordinate.txt")
    coordinateDict={}
    
    print("initialize jointE")
    newtranR = newtranR(fcodeList,entityList,relationList,tripleList,neg_dic,coordinateDict)
    
    #newtranR.getEntityCounts()
    newtranR.initialize()

    newtranR.newtranR(100000)
    newtranR.writeRelationVector(DATA_DIR+"relationVector.txt")
    newtranR.writeRelationMatrix(DATA_DIR+"relationMatrix.txt")
    newtranR.writeEntityVector(DATA_DIR+"entityVector.txt")
    newtranR.writefcodeVector(DATA_DIR+"fcodeVector.txt")

  