https://tianchi.aliyun.com/competition/entrance/231591/information?lang=en-us


File:			
relation2id.txt			action_type, temporal_pattern
fcode2id.txt			location ID
entity2id.txt			user ID
neg_dic.txt			negative location samples
koubei.txt			the train set, (user_id, location_id, action_type, temporal_pattern)
koubei_original.txt		(user_id, location_id, action_type,numeric type of date, date)


Action_type:
Sample   	Description
time_5		never
time_4		seldom
time_3		sometimes
time_2		often
time_1		always

Temporal_pattern:
Sample   	Description
type1		Soup/Porridge
type2		Hot Pot
type3		Others
type4		Chinese food
type5		Cookie
type6		Snack
type7		Tea
type8		Leisure food
type9		Fast food
type10		Convenience store
type11		Supermarket